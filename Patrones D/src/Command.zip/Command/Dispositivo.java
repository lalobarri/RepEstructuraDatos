package Command;

public interface Dispositivo {
	//M�todos generales para dispositivo
	
	public void encender();
	public void apagar();
	public void cargaSO();
	public void cargaConexion();
	public void cerrarConexion();
	

}
