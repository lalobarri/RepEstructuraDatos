package Builder;

public class Silla implements PlanSilla{
	private String patas;
	private String asiento;
	private String respaldo;
	
	public String getPatas() {
		return patas;
	}
	public void setPatas(String patas) {
		this.patas = patas;
	}
	public String getAsiento() {
		return asiento;
	}
	public void setAsiento(String asiento) {
		this.asiento = asiento;
	}
	public String getRespaldo() {
		return respaldo;
	}
	public void setRespaldo(String respaldo) {
		this.respaldo = respaldo;
	}
	

}
