package Builder;

public interface PlanSilla {
	public void setPatas(String patas);
	public void setAsiento(String asiento);
	public void setRespaldo(String respaldo);

}
