package AbstractFactory;

public class Bicicleta extends Vehiculo{
	private String marca;
	private int modelo;
	private String color;
		
	public Bicicleta(String marca, int modelo, String color) {	
		this.marca = marca;
		this.modelo = modelo;
		this.color = color;
	}

	//Se deben implementar los m�todos que est�n sin implementar de la clase abstracta
	@Override
	public String getMarca() {
		
		return marca;
	}

	@Override
	public int getModelo() {
		
		return modelo;
	}

	@Override
	public String getColor() {
		
		return color;
	}


}

