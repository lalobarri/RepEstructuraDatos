package AbstractFactory;

public interface VehiculoAbstractFactory {
	public Vehiculo crearVehiculo();

}
