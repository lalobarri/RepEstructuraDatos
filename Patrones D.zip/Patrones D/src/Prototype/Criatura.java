package Prototype;

public interface Criatura extends Cloneable{
	
	public Object clone();

}
