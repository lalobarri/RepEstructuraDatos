package SimpleFactory;

public class Cuadrado extends Figura{
	
	

	public Cuadrado(float ladoA) {
		super(ladoA);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void calculaArea() {
		// TODO Auto-generated method stub
		
		
	}

	@Override
	public void calculaPerimetro() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String toString() {
		return "Cuadrado [toString()=" + super.toString() + "]";
	}

	
	
	
	

}
